"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

// Calendar component that displays events in a monthly grid view
export function EventCalendar({ events }) {
  // State to track the currently displayed month
  const [currentMonth, setCurrentMonth] = useState(new Date())

  // Navigation functions for changing months
  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1))
  }

  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1))
  }

  // Get month name and year for display
  const monthName = currentMonth.toLocaleString("default", { month: "long" })
  const year = currentMonth.getFullYear()

  // Calculate calendar grid parameters
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate()
  const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay()

  // Create calendar days array with empty cells for proper alignment
  const calendarDays = []

  // Add empty cells for days before the first day of the month
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push(null)
  }

  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    calendarDays.push(day)
  }

  // Function to find events occurring on a specific day
  const getEventsForDay = (day) => {
    if (!day) return []

    const dateStr = `${monthName} ${day}, ${year}`
    return events.filter((event) => event.date.includes(dateStr))
  }

  return (
    <div className="space-y-4">
      {/* Calendar header with month/year display and navigation */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">
          {monthName} {year}
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={prevMonth}>
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Previous month</span>
          </Button>
          <Button variant="outline" size="icon" onClick={nextMonth}>
            <ChevronRight className="h-4 w-4" />
            <span className="sr-only">Next month</span>
          </Button>
        </div>
      </div>

      {/* Calendar grid with days of the week headers */}
      <div className="grid grid-cols-7 gap-1 text-center">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
          <div key={day} className="p-2 text-sm font-medium">
            {day}
          </div>
        ))}

        {/* Calendar day cells with events */}
        {calendarDays.map((day, index) => {
          const dayEvents = getEventsForDay(day)

          return (
            <div
              key={index}
              className={`min-h-[100px] rounded-md border p-1 ${!day ? "bg-muted/20" : "hover:bg-muted/50"}`}
            >
              {day && (
                <>
                  <div className="text-right text-sm">{day}</div>
                  <div className="mt-1 space-y-1">
                    {dayEvents.map((event) => (
                      <Link key={event.id} href={`/events/${event.id}`}>
                        <Card className="cursor-pointer p-1 text-xs hover:bg-primary hover:text-primary-foreground">
                          {event.title}
                        </Card>
                      </Link>
                    ))}
                  </div>
                </>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

