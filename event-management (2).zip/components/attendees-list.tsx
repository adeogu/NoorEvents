"use client"

import { useState } from "react"
import { Search } from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"

export function AttendeesList({ eventId }) {
  const [searchQuery, setSearchQuery] = useState("")

  // In a real app, you would fetch attendees based on the event ID
  const attendees = getAttendeesByEventId(eventId)

  const filteredAttendees = attendees.filter(
    (attendee) =>
      attendee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      attendee.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search attendees..."
          className="pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        {filteredAttendees.length > 0 ? (
          filteredAttendees.map((attendee) => (
            <div key={attendee.id} className="flex items-center gap-2 rounded-lg border p-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={attendee.avatar} alt={attendee.name} />
                <AvatarFallback>{attendee.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium">{attendee.name}</p>
                <p className="text-xs text-muted-foreground">{attendee.email}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-sm text-muted-foreground">No attendees found</p>
        )}
      </div>
    </div>
  )
}

// Sample data
function getAttendeesByEventId(eventId) {
  const attendeesMap = {
    "1": [
      { id: 1, name: "Alex Johnson", email: "alex@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 2, name: "Sam Taylor", email: "sam@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 3, name: "Jordan Lee", email: "jordan@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 4, name: "Casey Smith", email: "casey@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 5, name: "Riley Brown", email: "riley@example.com", avatar: "/placeholder.svg?height=32&width=32" },
    ],
    "2": [
      { id: 6, name: "Morgan Wilson", email: "morgan@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 7, name: "Taylor Davis", email: "taylor@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 8, name: "Jamie Miller", email: "jamie@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 8, name: "Jamie Miller", email: "jamie@example.com", avatar: "/placeholder.svg?height=32&width=32" },
      { id: 9, name: "Quinn Roberts", email: "quinn@example.com", avatar: "/placeholder.svg?height=32&width=32" },
    ],
  }

  return attendeesMap[eventId] || []
}

