"use client"

import { useEffect, useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { MapPin } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

export function EventMap({ events, activeEvent, setActiveEvent }) {
  const mapContainerRef = useRef(null)
  const [mapInstance, setMapInstance] = useState(null)
  const [markers, setMarkers] = useState([])
  const [isLoaded, setIsLoaded] = useState(false)
  const [isLoadingScript, setIsLoadingScript] = useState(false)
  const [mapError, setMapError] = useState(null)
  const leafletMapId = "leaflet-map"

  // Load Leaflet scripts
  useEffect(() => {
    if (typeof window === "undefined") return
    if (window.L) {
      setIsLoaded(true)
      return
    }

    const loadLeaflet = async () => {
      try {
        setIsLoadingScript(true)

        // Load Leaflet CSS
        const linkElement = document.createElement("link")
        linkElement.rel = "stylesheet"
        linkElement.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        linkElement.integrity = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
        linkElement.crossOrigin = ""
        document.head.appendChild(linkElement)

        // Load Leaflet JS
        const script = document.createElement("script")
        script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        script.integrity = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
        script.crossOrigin = ""
        script.async = true

        script.onload = () => {
          setIsLoaded(true)
          setIsLoadingScript(false)
        }

        script.onerror = (error) => {
          console.error("Error loading Leaflet:", error)
          setMapError("Failed to load map. Using fallback.")
          setIsLoadingScript(false)
        }

        document.head.appendChild(script)
      } catch (error) {
        console.error("Error setting up Leaflet:", error)
        setMapError("Error setting up map. Using fallback.")
        setIsLoadingScript(false)
      }
    }

    loadLeaflet()
  }, [])

  // Initialize the map once Leaflet is loaded
  useEffect(() => {
    if (!isLoaded || !mapContainerRef.current || mapInstance) return

    try {
      if (window.L) {
        // Center map on Ireland
        const irelandCenter = [53.1424, -7.6921]
        const map = window.L.map(mapContainerRef.current).setView(irelandCenter, 7)

        // Add OpenStreetMap tile layer
        window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(map)

        setMapInstance(map)
      } else {
        setMapError("Map library not available. Using fallback.")
      }
    } catch (error) {
      console.error("Error initializing map:", error)
      setMapError("Error initializing map. Using fallback.")
    }
  }, [isLoaded, mapInstance])

  // Add markers for events
  useEffect(() => {
    if (!mapInstance || !events || !events.length) return
    if (!window.L) return

    // Clear existing markers
    markers.forEach((marker) => {
      if (marker && marker.remove) {
        marker.remove()
      }
    })

    // Create new markers
    const newMarkers = events
      .map((event) => {
        try {
          if (
            !event.coordinates ||
            typeof event.coordinates.lat !== "number" ||
            typeof event.coordinates.lng !== "number"
          ) {
            console.error("Invalid coordinates for event:", event.title, event.coordinates)
            return null
          }

          // Create custom icon
          const customIcon = window.L.divIcon({
            html: `<div class="map-marker ${activeEvent === event.id ? "active" : ""}">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" class="lucide lucide-map-pin">
                    <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                    <circle cx="12" cy="10" r="3"></circle>
                  </svg>
                </div>`,
            className: "",
            iconSize: [24, 40],
            iconAnchor: [12, 40],
          })

          // Create marker
          const marker = window.L.marker([event.coordinates.lat, event.coordinates.lng], {
            icon: customIcon,
            title: event.title,
          }).addTo(mapInstance)

          // Add popup
          marker.bindPopup(`
          <div class="map-popup">
            <h3 class="font-bold">${event.title}</h3>
            <p>${event.location}</p>
            <p>${event.date}</p>
          </div>
        `)

          // Add click event
          marker.on("click", () => {
            setActiveEvent(activeEvent === event.id ? null : event.id)
          })

          return marker
        } catch (error) {
          console.error("Error creating marker:", error)
          return null
        }
      })
      .filter(Boolean)

    setMarkers(newMarkers)

    // Add CSS for markers
    if (!document.getElementById("map-marker-styles")) {
      const style = document.createElement("style")
      style.id = "map-marker-styles"
      style.innerHTML = `
        .map-marker {
          color: #3b82f6;
          transition: transform 0.2s ease, filter 0.2s ease;
        }
        .map-marker.active, .map-marker:hover {
          color: #1d4ed8;
          transform: scale(1.2) translateY(-5px);
          filter: drop-shadow(0 4px 3px rgb(0 0 0 / 0.2)) drop-shadow(0 2px 2px rgb(0 0 0 / 0.1));
        }
        .map-popup h3 {
          font-weight: bold;
          margin-bottom: 4px;
        }
        .map-popup p {
          margin: 2px 0;
          font-size: 0.875rem;
        }
      `
      document.head.appendChild(style)
    }

    // Update marker active state when activeEvent changes
    if (activeEvent) {
      const activeMarker = newMarkers.find((_, index) => events[index]?.id === activeEvent)
      if (activeMarker) {
        activeMarker.openPopup()
      }
    }
  }, [mapInstance, events, activeEvent, setActiveEvent])

  // If Leaflet is loaded and initialized, render the map
  if (isLoaded && !mapError) {
    return (
      <div className="relative h-[400px] w-full">
        <div id={leafletMapId} ref={mapContainerRef} className="h-full w-full z-0" />
      </div>
    )
  }

  // Fallback simulated map
  return (
    <div className="relative h-[400px] w-full bg-[#e5e3df] overflow-hidden">
      {mapError && (
        <div className="absolute top-2 left-2 right-2 bg-destructive/90 text-white text-sm p-2 rounded-md z-10">
          {mapError}
        </div>
      )}

      {/* Simulated map with Ireland map background */}
      <div className="absolute inset-0 overflow-hidden">
        <img
          src="/placeholder.svg?height=400&width=800&text=Map+of+Ireland"
          alt="Map of Ireland"
          className="h-full w-full object-cover"
        />
      </div>

      {/* Event location pins */}
      {events.map((event) => {
        // Calculate positions based on real coordinates but scaled to our container
        const left = ((event.coordinates.lng + 10) / 5) * 100
        const top = (55 - event.coordinates.lat) * 10
        const isActive = activeEvent === event.id

        return (
          <TooltipProvider key={event.id}>
            <Tooltip open={isActive}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn("absolute text-primary hover:text-primary map-pin", isActive && "active")}
                  style={{
                    left: `${Math.min(Math.max(left, 5), 95)}%`,
                    top: `${Math.min(Math.max(top, 5), 95)}%`,
                  }}
                  onClick={() => setActiveEvent(isActive ? null : event.id)}
                  onMouseEnter={() => setActiveEvent(event.id)}
                  onMouseLeave={() => setActiveEvent(null)}
                >
                  <MapPin className={cn("h-6 w-6", isActive ? "fill-black/50" : "fill-black/20")} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top" className="p-0 overflow-hidden border-none shadow-lg animate-fade-in">
                <div className="w-64">
                  <div className="bg-black p-3 text-white">
                    <p className="font-medium">{event.title}</p>
                    <div className="flex items-center gap-1 text-xs mt-1">
                      <MapPin className="h-3 w-3" />
                      <span>{event.location}</span>
                    </div>
                  </div>
                  <div className="p-3 bg-card">
                    <p className="text-xs text-muted-foreground mb-2">{event.description}</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        {event.date}
                      </Badge>
                      <Link href={`/events/${event.id}`} className="text-xs text-black hover:underline">
                        View details
                      </Link>
                    </div>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )
      })}

      {/* Map attribution */}
      <div className="absolute bottom-1 right-1 text-[10px] text-black/70">Map data © {new Date().getFullYear()}</div>
    </div>
  )
}

