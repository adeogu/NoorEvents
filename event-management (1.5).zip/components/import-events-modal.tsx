"use client"

import { useState } from "react"
import { Loader2, RefreshCw } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { toast } from "@/hooks/use-toast"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export function ImportEventsModal({ isOpen, onClose, onImport }) {
  const [isLoading, setIsLoading] = useState(false)
  const [scrapedEvents, setScrapedEvents] = useState([])
  const [selectedEvents, setSelectedEvents] = useState({})
  const [error, setError] = useState(null)

  const fetchEvents = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/scrape-events")

      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`)
      }

      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error(`Expected JSON response but got ${contentType}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      setScrapedEvents(data.events || [])

      // Initialize all events as selected
      const initialSelected = {}
      data.events.forEach((event) => {
        initialSelected[event.id] = true
      })
      setSelectedEvents(initialSelected)

      // Show success toast
      if (data.events && data.events.length > 0) {
        toast({
          title: "Events found",
          description: `Found ${data.events.length} Muslim events in Dublin.`,
        })
      } else {
        toast({
          title: "No events found",
          description: "No events were found matching your criteria.",
        })
      }
    } catch (error) {
      console.error("Error fetching scraped events:", error)
      setError(error.message || "Failed to fetch events")
      toast({
        title: "Error",
        description: "Failed to fetch events. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const toggleEventSelection = (eventId) => {
    setSelectedEvents((prev) => ({
      ...prev,
      [eventId]: !prev[eventId],
    }))
  }

  const handleImport = () => {
    const eventsToImport = scrapedEvents.filter((event) => selectedEvents[event.id])
    onImport(eventsToImport)
    toast({
      title: "Events imported",
      description: `Successfully imported ${eventsToImport.length} events.`,
    })
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Import Muslim Events</DialogTitle>
          <DialogDescription>Import Muslim community events from Dublin, Ireland.</DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {scrapedEvents.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 space-y-4">
              <RefreshCw className="h-12 w-12 text-muted-foreground" />
              <p className="text-muted-foreground">Click the button below to fetch Muslim events</p>
              <Button onClick={fetchEvents} disabled={isLoading} className="bg-black text-white hover:bg-black/90">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Fetching Events...
                  </>
                ) : (
                  "Fetch Events"
                )}
              </Button>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-muted-foreground">Found {scrapedEvents.length} events</p>
                <Button variant="outline" size="sm" onClick={fetchEvents} disabled={isLoading}>
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                </Button>
              </div>

              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-3">
                  {scrapedEvents.map((event) => (
                    <Card key={event.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        <div className="flex items-start p-4">
                          <Checkbox
                            id={`event-${event.id}`}
                            checked={selectedEvents[event.id] || false}
                            onCheckedChange={() => toggleEventSelection(event.id)}
                            className="mr-3 mt-1"
                          />
                          <div className="flex-1">
                            <h4 className="font-medium">{event.title}</h4>
                            <p className="text-sm text-muted-foreground">{event.date}</p>
                            <p className="text-sm text-muted-foreground">{event.location}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            disabled={isLoading || scrapedEvents.length === 0 || Object.values(selectedEvents).every((v) => !v)}
            className="bg-black text-white hover:bg-black/90"
          >
            Import Selected Events
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

