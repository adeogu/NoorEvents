"use client"

import * as React from "react"
import { Clock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"

export function TimePickerDemo() {
  const [time, setTime] = React.useState("")

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant={"outline"}
          className={cn("w-full justify-start text-left font-normal", !time && "text-muted-foreground")}
        >
          <Clock className="mr-2 h-4 w-4" />
          {time ? time : <span>Select time</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-4">
        <div className="space-y-2">
          <div className="grid gap-2">
            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-1">
                <Label htmlFor="hours">Hours</Label>
                <Input id="hours" className="w-full" type="number" min={0} max={23} placeholder="00" />
              </div>
              <div className="grid gap-1">
                <Label htmlFor="minutes">Minutes</Label>
                <Input id="minutes" className="w-full" type="number" min={0} max={59} placeholder="00" />
              </div>
            </div>
          </div>
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => {
                setTime("")
              }}
            >
              Clear
            </Button>
            <Button
              onClick={() => {
                const hours = document.getElementById("hours").value || "00"
                const minutes = document.getElementById("minutes").value || "00"
                setTime(`${hours.padStart(2, "0")}:${minutes.padStart(2, "0")}`)
              }}
            >
              Set time
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}

