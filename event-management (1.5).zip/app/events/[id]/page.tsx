"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { CalendarDays, ChevronLeft, Clock, MapPin, Plus, Upload, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"

export default function EventPage({ params }) {
  const [isLoading, setIsLoading] = useState(true)

  // In a real app, you would fetch the event data based on the ID
  const event = getEventById(params.id)
  const [images, setImages] = useState(event?.images || [])
  const [showUpload, setShowUpload] = useState(false)
  const [newImagePreview, setNewImagePreview] = useState(null)

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (!event && !isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Event not found</h2>
          <p className="text-muted-foreground mb-4">The event you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/">Return to Dashboard</Link>
          </Button>
        </div>
      </div>
    )
  }

  const handleImageChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setNewImagePreview(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleAddImage = () => {
    if (newImagePreview) {
      setImages([...images, newImagePreview])
      setNewImagePreview(null)
      setShowUpload(false)
      toast({
        title: "Image added",
        description: "Your image has been added to the event.",
      })
    }
  }

  const handleCancelUpload = () => {
    setNewImagePreview(null)
    setShowUpload(false)
  }

  return (
    <div className="flex min-h-screen w-full flex-col bg-gradient-to-b from-background to-muted/30">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background/80 backdrop-blur-md px-4 md:px-6">
        <Button variant="ghost" size="icon" asChild className="hover:bg-muted transition-colors">
          <Link href="/">
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <div className="flex flex-1 items-center gap-2">
          {isLoading ? (
            <div className="h-6 w-40 bg-muted animate-pulse rounded-md"></div>
          ) : (
            <h1 className="text-xl font-semibold">{event.title}</h1>
          )}
        </div>
      </header>
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8 animate-fade-in">
        {isLoading ? (
          <div className="grid gap-4">
            <Card className="border-none shadow-lg">
              <CardHeader className="animate-pulse">
                <div className="h-8 w-2/3 bg-muted rounded-md"></div>
                <div className="h-4 w-full bg-muted rounded-md"></div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="h-12 bg-muted rounded-md"></div>
                  <div className="h-12 bg-muted rounded-md"></div>
                </div>
                <Separator />
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="h-12 bg-muted rounded-md"></div>
                  <div className="h-12 bg-muted rounded-md"></div>
                </div>
                <Separator />
                <div>
                  <div className="h-6 w-40 bg-muted rounded-md mb-4"></div>
                  <div className="space-y-2">
                    <div className="h-4 w-full bg-muted rounded-md"></div>
                    <div className="h-4 w-full bg-muted rounded-md"></div>
                    <div className="h-4 w-2/3 bg-muted rounded-md"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <>
            <Card className="border-none shadow-lg overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl">{event.title}</CardTitle>
                    <CardDescription>{event.description}</CardDescription>
                  </div>
                  <Badge className="bg-secondary hover:bg-secondary/90">{event.eventType || "Event"}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 p-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-center gap-3">
                    <div className="rounded-full bg-primary/10 p-2">
                      <CalendarDays className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Date</p>
                      <p className="text-sm text-muted-foreground">{event.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="rounded-full bg-primary/10 p-2">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Time</p>
                      <p className="text-sm text-muted-foreground">{event.time}</p>
                    </div>
                  </div>
                </div>
                <Separator />
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-center gap-3">
                    <div className="rounded-full bg-primary/10 p-2">
                      <MapPin className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Location</p>
                      <p className="text-sm text-muted-foreground">{event.location}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="rounded-full bg-primary/10 p-2">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Attendees</p>
                      <p className="text-sm text-muted-foreground">{event.attendees} registered</p>
                    </div>
                  </div>
                </div>
                <Separator />
                <div>
                  <h3 className="text-lg font-medium mb-3">About this event</h3>
                  <p className="text-muted-foreground">
                    {event.longDescription || "No detailed description available for this event."}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-primary/10 to-secondary/10">
                <div>
                  <CardTitle>Event Images</CardTitle>
                  <CardDescription>View and add images for this event</CardDescription>
                </div>
                <Button
                  onClick={() => setShowUpload(true)}
                  className="bg-black text-white hover:bg-black/90 transition-opacity"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Image
                </Button>
              </CardHeader>
              <CardContent className="p-6">
                {showUpload && (
                  <div className="mb-6 space-y-4 rounded-lg border p-4 animate-fade-in">
                    <h4 className="font-medium">Upload New Image</h4>
                    {newImagePreview ? (
                      <div className="relative aspect-video w-full overflow-hidden rounded-md border">
                        <img
                          src={newImagePreview || "/placeholder.svg"}
                          alt="New image preview"
                          className="h-full w-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="relative flex aspect-video w-full flex-col items-center justify-center rounded-md border border-dashed hover:bg-muted/50 transition-colors cursor-pointer">
                        <Upload className="mb-2 h-8 w-8 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Upload event image</p>
                        <input
                          type="file"
                          accept="image/*"
                          className="absolute inset-0 cursor-pointer opacity-0"
                          onChange={handleImageChange}
                        />
                      </div>
                    )}
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={handleCancelUpload}>
                        Cancel
                      </Button>
                      <Button
                        onClick={handleAddImage}
                        disabled={!newImagePreview}
                        className="bg-black text-white hover:bg-black/90 transition-opacity"
                      >
                        Add Image
                      </Button>
                    </div>
                  </div>
                )}

                {images.length > 0 ? (
                  <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
                    {images.map((image, index) => (
                      <div
                        key={index}
                        className="relative aspect-video overflow-hidden rounded-md border group hover:shadow-md transition-shadow"
                      >
                        <img
                          src={image || "/placeholder.svg"}
                          alt={`Event image ${index + 1}`}
                          className="h-full w-full object-cover transition-transform group-hover:scale-105 duration-300"
                        />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex aspect-video w-full flex-col items-center justify-center rounded-md border border-dashed">
                    <Upload className="mb-2 h-8 w-8 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">No images yet - add some!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  )
}

// Update the getEventById function to include images
function getEventById(id) {
  const events = [
    {
      id: "1",
      title: "Eid al-Fitr Celebration",
      description: "Ireland's biggest Eid celebration with food, activities and prayers",
      longDescription:
        "Join us for Ireland's largest Eid al-Fitr celebration at the iconic Convention Centre Dublin. This full-day event features communal prayers, delicious food from around the Muslim world, activities for children, and cultural performances. The celebration brings together Muslims from across Ireland to mark the end of Ramadan with joy and community spirit.",
      date: "March 20, 2025",
      time: "9:00 AM - 5:00 PM",
      location: "Convention Centre Dublin",
      attendees: 120,
      coordinates: { lat: 53.34774, lng: -6.24059 },
      eventType: "Religious",
      image: "/placeholder.svg?height=200&width=400&text=Eid+al-Fitr+Celebration",
      images: [],
    },
    {
      id: "2",
      title: "Islamic Art Exhibition",
      description: "A showcase of Islamic calligraphy and art from around the world",
      longDescription:
        "Experience the beauty of Islamic art at the Cork Opera House. This exhibition brings together traditional and contemporary Islamic artists showcasing calligraphy, geometric patterns, arabesque designs, and miniature paintings. From ancient manuscripts to modern interpretations, the Islamic Art Exhibition highlights the rich artistic heritage of Islamic civilization in one of Ireland's most beautiful venues.",
      date: "March 25, 2025",
      time: "2:00 PM - 10:00 PM",
      location: "Cork Opera House",
      attendees: 75,
      coordinates: { lat: 51.89997, lng: -8.47061 },
      eventType: "Cultural",
      image: "/placeholder.svg?height=200&width=400&text=Islamic+Art+Exhibition",
      images: [],
    },
  ]

  return events.find((event) => event.id === id)
}

